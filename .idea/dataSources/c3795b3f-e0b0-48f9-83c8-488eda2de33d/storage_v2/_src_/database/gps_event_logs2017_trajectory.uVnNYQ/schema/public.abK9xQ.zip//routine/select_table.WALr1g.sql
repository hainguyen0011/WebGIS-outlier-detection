create procedure select_table(id integer)
    language sql
as
$$
select * 
		from gps_logs_2017_trajectory 
		where trajectory_id = id
		order by trajline_id
		limit 100

$$;

alter procedure select_table(integer) owner to postgres;

