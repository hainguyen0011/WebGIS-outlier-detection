create procedure create_view(name character varying, id integer)
    language sql
as
$$
    CREATE VIEW name as 
		(select * 
		from gps_logs_2017_trajectory 
		where trajectory_id = id
		order by trajline_id
		limit 100)
    $$;

alter procedure create_view(varchar, integer) owner to postgres;

